package com.example.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class OrderController {
	
	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping("/order")
	public ResponseEntity<String> getOrder(){
		//String response = restTemplate.getForObject("http://localhost:9090/itemController", String.class);
		String response = restTemplate.getForObject("http://EurekaItemService/itemController", String.class);
		return new ResponseEntity<String>(response,HttpStatus.OK);
	}
	
}
