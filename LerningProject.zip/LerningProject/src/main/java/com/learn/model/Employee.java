package com.learn.model;

import java.sql.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name="Employee")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Id")
	private long id;
	
	@Column(name="Name")
	@NotNull(message="Enter name")
	private String name;
	
	@Column(name="Age")
	private Long age = 20L;
	
	@Column(name="location")
	private String location;
	
	@Column(name="email")
	@NotNull(message="Enter Valid Email")
	private String email;
	
	@Column(name="department")
	private String department;
	
	//TimeStamp for Create
	@CreationTimestamp
	@Column(name="Created_At", nullable=false, updatable=false)
	private Date created_at;
	
	//TimeStamp for update
	@UpdateTimestamp
	@Column(name="LastUpdate")
	private Date update_at;
	
	//getter and setter
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	public Long getAge() {
		return age;
	}
	public void setAge(Long age) {
		this.age = age;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
}
