package com.learn.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.learn.model.Employee;
import com.learn.service.EmployeeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/employees")
public class EmployeeController {
	
	@Autowired
	private EmployeeService eservice;
	
	//Handler Methods
//	@GetMapping("/allemp")
//	public String getEmployee() {
//		return "display all employees";
//	}
	@GetMapping("/allemp")
	public List<Employee> getemp(){
		return eservice.getEmployee();
	}
	
	@GetMapping("/dec-orderemp")
	public List<Employee> getempbydec(){
		return eservice.descidEmployee();
	}
	
//	@GetMapping("/empbyid/{id}")
//	public String getemp(@PathVariable("id") Long id) {
//		return "fetch emp details usign id: " +id;
//	}
	@GetMapping("/empbyid/{id}")
	public Employee getemp(@PathVariable("id") Long id) {
		return eservice.getSingleEmployee(id);
	}
	
	
	//@PostMapping("/saveemp")
//	public String savemp(@RequestBody Employee emp) {
//		return "Saving emp details to the database: " +emp;
//	}
	
	
	//chage http request code
	@PostMapping("/saveemp")
	public ResponseEntity<Employee> saveEmployee(@Valid @RequestBody Employee employee) {
	    return ResponseEntity.status(HttpStatus.CREATED).body(eservice.saveemp(employee));
	}

	
	
//	@PutMapping("/updateemp/{id}")
//	public String updateEmp(@PathVariable Long id, @RequestBody Employee employee) {
//        System.out.println("updated successfully");
//        return "Updated employee details for id " + id + ": " + employee;
//	}
	
	
	@PutMapping("/updateemp/{id}")
	public Employee updateEmp(@PathVariable Long id, @RequestBody Employee employee) {
        employee.setId(id);
        return eservice.updateEmployee(employee);
	}
	
	
	
//	@DeleteMapping("/delemp")
//	public String delemp(@RequestParam Long id) {
//		return "delete using request param:" +id; 	
//	}
	
	@DeleteMapping("/delemp")
	public void delemp(@RequestParam Long id) {
		eservice.deleteEmployee(id); 	
	}
	
	
	//find by employee name
	
	@GetMapping("/findbyname")
	public ResponseEntity <List<Employee>> getEmployeeByName(@RequestParam String name){
		return new ResponseEntity<List<Employee>>(eservice.getEmployeeByName(name), HttpStatus.OK);
	}
	
	
	@GetMapping("/findlocationORname/{name}/{location}")
	public List<Employee> getEmpbynameOrLocation(@PathVariable String name, @PathVariable String location){
		return eservice.getEmpbynameOrLocation(name,location);
	}

}
