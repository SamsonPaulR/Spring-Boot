package com.learn.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.learn.model.Employee;
import com.learn.repo.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeRepository emprepo;

	@Override
	public List<Employee> descidEmployee() {
		Sort sort = Sort.by(Sort.Direction.DESC,"id");
		return emprepo.findAll(sort);//get all employee
	}
	
	@Override
	public List<Employee> getEmployee() {
		return emprepo.findAll();//get all employee
	}

	@Override
	public Employee saveemp(Employee employee) {
		
		return emprepo.save(employee);//insert single employee
	}

	@Override
	public Employee getSingleEmployee(Long id) {
		Optional <Employee> employee = emprepo.findById(id);
		if(employee.isPresent()) {
			return employee.get();//get specific employee
		}
		throw new RuntimeException("Employee not found:" +id);
	}

	@Override
	public void deleteEmployee(Long id) {
		emprepo.deleteById(id);//delete specific employee
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		return emprepo.save(employee);//update employee by id
	}

	
	//Find By Name
	
	@Override
	public List<Employee> getEmployeeByName(String name) {
		return emprepo.findByName(name);
	}

	@Override
	public List<Employee> getEmpbynameOrLocation(String name, String location) {
		return emprepo.getEmpByNameAndLocation(name, location);
	}


}
