package com.learn.service;

import java.util.List;

import com.learn.model.Employee;

public interface EmployeeService {
	//show all employees
	List<Employee> getEmployee();
	
	//insert single employee
	Employee saveemp(Employee employee);
	
	//show single employee by using id
	Employee getSingleEmployee(Long id);
	
	//delete employee
	void  deleteEmployee(Long id);
	
	//Update employee details using Id
	Employee updateEmployee(Employee employee);
	
	//find by name
	List<Employee> getEmployeeByName(String name);

	List<Employee> descidEmployee();
	
	List<Employee> getEmpbynameOrLocation(String name, String location);

}
