package com.learn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningProjectApplication {
    public static void main(String[] args) {
        SpringApplication.run(LearningProjectApplication.class, args);
    }
}
