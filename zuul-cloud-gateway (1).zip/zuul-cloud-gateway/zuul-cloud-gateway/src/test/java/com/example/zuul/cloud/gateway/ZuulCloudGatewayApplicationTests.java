package com.example.zuul.cloud.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulCloudGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
