package com.example.JPAValidations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaValidationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
