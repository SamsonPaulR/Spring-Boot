package com.example.FirstSpringBoot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.FirstSpringBoot.model.Department;
import com.example.FirstSpringBoot.model.Employee;
import com.example.FirstSpringBoot.service.DepartmentService;

import java.util.List;

@RestController
@RequestMapping("/departments")
public class DepartmentController {
@Autowired
    private  DepartmentService departmentService;

@PostMapping("/addDeptWithEmp")
public Department saveDepartmentWithEmployees(@RequestBody Department department) {
    return departmentService.saveDepartmentWithEmployees(department);
}

   
    @GetMapping("/{id}/employees")
    public List<Employee> getAllEmployeesByDepartment(@PathVariable Long id) {
        return departmentService.getEmployeesByDepartment(id);
    }

    // Endpoint to get the department of an employee
    @GetMapping("/employees/{id}/department")
    public Department getDepartmentOfEmployee(@PathVariable Long id) {
        return departmentService.getDepartmentOfEmployee(id);
    }
}

