package com.example.FirstSpringBoot.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.FirstSpringBoot.model.Department;
import com.example.FirstSpringBoot.model.Employee;
import com.example.FirstSpringBoot.repository.DepartmentRepository;
import com.example.FirstSpringBoot.repository.EmployeeRepository;

import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService {
@Autowired
    private  DepartmentRepository departmentRepository;
@Autowired    
private  EmployeeRepository employeeRepository;

    
//@Transactional
public Department saveDepartmentWithEmployees(Department department) {
    for (Employee employee : department.getEmployees()) {
        employee.setDepartment(department);
    }
    return departmentRepository.save(department);
}

    public List<Employee> getEmployeesByDepartment(Long departmentId) {
        Optional<Department> department = departmentRepository.findById(departmentId);
        return department.map(Department::getEmployees).orElse(null);
    }

    public Department getDepartmentOfEmployee(Long employeeId) {
        Optional<Employee> employee = employeeRepository.findById(employeeId);
                if (employee.isPresent()) {
                	System.out.println(employee.get());
            return employee.get().getDepartment();
        } else {
            return null;
        }
    }
}
