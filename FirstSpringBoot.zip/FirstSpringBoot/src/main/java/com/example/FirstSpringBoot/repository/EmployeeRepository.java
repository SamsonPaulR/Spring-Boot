package com.example.FirstSpringBoot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.FirstSpringBoot.model.Employee;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByDepartmentId(Long departmentId);
}
